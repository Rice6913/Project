/*Christopher Rice
Project 2 BankApp
CS-210*/

#include <iostream>
#include <iomanip>

using namespace std;

int main() {
	//Declare variables for user input
	float initialInvestment, monthlyDeposit, annualInterest, months, years;

	//Declare variables to store calculations
	float totalAmount, interestAmount, yearlyTotalInterest;

	//Display menu
	cout << "**********************************" << endl;
	cout << "*********** Data Input ***********" << endl;
	cout << "Initial Investment Amount: " << endl;
	cout << "Monthly Deposit: " << endl;
	cout << "Annual Interest: " << endl;
	cout << "Number of years: " << endl;

	system("PAUSE");

	//Get user input
	cout << "**********************************" << endl;
	cout << "*********** Data Input ***********" << endl;
	cout << "Initial Investment Amount: $" << endl;
	cin >> initialInvestment;
	cout << "Monthly Deposit: $" << endl;
	cin >> monthlyDeposit;
	cout << "Annual Interest: %" << endl;
	cin >> annualInterest;
	cout << "Number of years: " << endl;
	cin >> years;
	months = years * 12;

	system("PAUSE");

	//Update total amount to initial investment
	totalAmount = initialInvestment;

	//Displays end balance without interest
	cout << endl << "Balance and Interest Without Additional Monthly Deposits" << endl;
	cout << "================================================================" << endl;
	cout << "Year          Year End Balance          Year End Earned Interest" << endl;
	cout << "----------------------------------------------------------------" << endl;

	//Calculates the years interest and final total
	for (int i = 0; i < years; i++) {
		//Calculate
		interestAmount = ((totalAmount) * (annualInterest / 100));

		//Calculate year end total
		totalAmount = totalAmount + interestAmount;

		//Show in dollar amounts to 2 decimal places
		cout << (i + 1) << "\t\t$" << fixed << setprecision(2) << totalAmount << "\t\t\t$" << interestAmount << endl;
	}

	//Calculates the monthly interest
	totalAmount = initialInvestment;

	//Show balance with interest and deposits
	cout << endl << "Balance and Interest With Additional Monthly Deposits" << endl;
	cout << "================================================================" << endl;
	cout << "Year          Year End Balance          Year End Earned Interest" << endl;
	cout << "----------------------------------------------------------------" << endl;

	//Calculate yearly interest and totals the year
	for (int i = 0; i < years; i++) {
		//Initialize yearly interest to 0
		yearlyTotalInterest = 0;

		for (int j = 0; j < 12; j++) {
			//Calculate monthly interest amount
			interestAmount = (((totalAmount + monthlyDeposit) * (annualInterest / 100)) / 12);

			yearlyTotalInterest = yearlyTotalInterest + interestAmount;

			totalAmount = totalAmount + monthlyDeposit + interestAmount;
		}

		cout << (i + 1) << "\t\t$" << fixed << setprecision(2) << totalAmount << "\t\t\t$" << yearlyTotalInterest << endl;
	}
	return 0;
}